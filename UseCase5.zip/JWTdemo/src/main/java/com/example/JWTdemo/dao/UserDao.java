package com.example.JWTdemo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.JWTdemo.model.user;

@Repository
public interface UserDao extends CrudRepository<user, Long> {
    user findByUsername(String username);
}
