package com.example.JWTdemo.service;

import com.example.JWTdemo.model.user;

import java.util.List;

public interface UserService {

    user save(user user);
    List<user> findAll();
    void delete(long id);
}
