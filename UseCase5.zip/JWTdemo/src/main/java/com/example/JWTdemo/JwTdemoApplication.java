package com.example.JWTdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwTdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwTdemoApplication.class, args);
	}

}
